<?php

include ('security.php');

$connection = new mysqli('localhost','root','','compass');


if (isset($_POST['login']))
{
    $username=$_POST['username'];
    $password=$_POST['password'];

    $query = "select * from users where username='$username' and password='$password'";
    $query_run = mysqli_query($connection, $query);

    echo 'successful';


    if (mysqli_fetch_array($query_run))
    {
        echo 'successful';
        $_SESSION['username'] = $username;
        header('Location: dashboard.php');
}
    else{
        $_SESSION['status'] = "Usernam or password is invalid";
        header('Location: login.php');

    }
}


