<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "compass";
$mysqli= new mysqli($servername, $username,$password, $dbname) or die(mysqli_error($mysqli));


?>